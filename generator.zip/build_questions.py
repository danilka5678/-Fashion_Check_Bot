"""Собирает questions.json и detective.json из таблиц в папке data/.

Запуск:  python build_questions.py
Чтобы добавить вопросы, дополни таблицы в data/ и запусти скрипт заново.
Сложность d: 1 — лёгкая, 2 — средняя, 3 — сложная (зависит от известности факта и типа вопроса).
"""
import json
import random
from pathlib import Path

R = random.Random(2026)
BASE = Path(__file__).parent
DATA = BASE / "data"

LOC = {
    "Франция": "во Франции", "Италия": "в Италии", "США": "в США", "Великобритания": "в Великобритании",
    "Япония": "в Японии", "Германия": "в Германии", "Испания": "в Испании", "Бельгия": "в Бельгии",
    "Швеция": "в Швеции", "Канада": "в Канаде", "Финляндия": "в Финляндии", "Нидерланды": "в Нидерландах",
    "Швейцария": "в Швейцарии", "Австрия": "в Австрии", "Австралия": "в Австралии",
}


def rows(*names):
    out = []
    for n in names:
        for line in (DATA / n).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                out.append([None if x.strip() == "-" else x.strip() for x in line.split("|")])
    return out


def cap(s):
    return s[0].upper() + s[1:]


def low(s):
    return s[0].lower() + s[1:]


def clamp(d):
    return max(1, min(3, d))


Q = []
seen = set()


def add(cat, d, q, correct, wrong, fact, key, keep=False):
    opts = [correct] + list(wrong)
    if len(opts) != 4 or len(set(opts)) != 4 or None in opts:
        return
    if max(len(o) for o in opts) > 64:
        return
    if len(correct) > 3 and correct.lower() in q.lower():
        return
    sig = (q, tuple(sorted(opts)))
    if sig in seen:
        return
    seen.add(sig)
    if not keep:
        R.shuffle(opts)
    item = {"cat": cat, "d": clamp(d), "q": q, "options": opts, "answer": opts.index(correct),
            "fact": fact, "key": key}
    if keep:
        item["keep"] = 1
    Q.append(item)


def sample(pool, n, exclude=()):
    pool = [p for p in dict.fromkeys(pool) if p not in exclude and p is not None]
    return R.sample(pool, n) if len(pool) >= n else None


def year_opts(y, mode):
    if mode == "wide":
        c, tries = set(), 0
        while len(c) < 3 and tries < 800:
            tries += 1
            v = y + R.choice([-1, 1]) * R.randint(18, 70)
            if 1750 <= v <= 2024 and all(abs(v - x) >= 12 for x in c | {y}):
                c.add(v)
    else:
        offs = [o for o in range(-6, 7) if o and 1750 <= y + o <= 2025]
        c = {y + o for o in R.sample(offs, 3)}
    if len(c) != 3:
        return None
    return sorted(c | {y})


def add_year(cat, tier, q, y, fact, key):
    for mode, d in (("wide", tier), ("narrow", tier + 1)):
        o = year_opts(y, mode)
        if o:
            correct = str(y)
            add(cat, d, q, correct, [str(v) for v in o if v != y], fact, f"{key}:{mode}", keep=True)


# ---------- бренды ----------
B = []
for n, country, year, founder, city, sig, tier in rows("brands_a.txt", "brands_b.txt", "brands_c.txt", "brands_d.txt"):
    B.append(dict(name=n, country=country, year=int(year) if year else None, founder=founder,
                  city=city, sig=sig, tier=int(tier)))


def bfact(b):
    s = b["name"]
    if b["year"]:
        s += f" основан в {b['year']} году"
    where = ", ".join(x for x in (b["city"], b["country"]) if x)
    if where:
        s += f" ({where})"
    if b["founder"]:
        s += f", основатель — {b['founder']}"
    return s + f". Известен: {b['sig']}."


NAMESAKE = {"Ralph Lauren", "Calvin Klein", "Tommy Hilfiger", "Michael Kors", "Donna Karan", "Vera Wang",
            "Oscar de la Renta", "Carolina Herrera", "Kate Spade", "Tory Burch", "Paul Smith", "Fred Perry",
            "Stella McCartney", "Manolo Blahnik", "Giorgio Armani", "Roberto Cavalli", "Jil Sander", "Hugo Boss",
            "Dries Van Noten", "Ann Demeulemeester", "Raf Simons", "Isabel Marant", "Sonia Rykiel",
            "Christian Lacroix", "Christian Louboutin", "Pierre Cardin", "Alexander McQueen", "Yves Saint Laurent",
            "Jean Paul Gaultier", "Brunello Cucinelli", "Ermenegildo Zegna", "Salvatore Ferragamo",
            "Roger Vivier", "Emilio Pucci", "Nina Ricci", "Paco Rabanne", "Vivienne Westwood", "Halston",
            "Jimmy Choo", "Bally", "Ellesse", "Marni"}
names = [b["name"] for b in B]
for b in B:
    n, t, f = b["name"], b["tier"], bfact(b)
    k = n
    # основатель
    if b["founder"] and n not in NAMESAKE:
        same = [x["founder"] for x in B if x["country"] == b["country"]]
        w = sample(same, 3, [b["founder"]]) or sample([x["founder"] for x in B], 3, [b["founder"]])
        if w:
            add("brands", t, f"Кто основал {n}?", b["founder"], w, f, f"founder:{k}")
        w = sample(names, 3, [n])
        add("brands", t, f"Какой бренд основал(и) {b['founder']}?", n, w, f, f"rfounder:{k}")
    # страна
    if b["country"]:
        w = sample(list(LOC), 3, [b["country"]])
        add("brands", t - 1, f"В какой стране основан {n}?", b["country"], w, f, f"country:{k}")
        w = sample([x["name"] for x in B if x["country"] and x["country"] != b["country"]], 3)
        if b["country"] in LOC:
            add("brands", t, f"Какой из этих брендов основан {LOC[b['country']]}?", n, w, f, f"rcountry:{k}")
    # город
    if b["city"]:
        same = [x["city"] for x in B if x["country"] == b["country"]]
        w = sample(same, 3, [b["city"]]) or sample([x["city"] for x in B], 3, [b["city"]])
        if w:
            add("brands", t + 1, f"В каком городе основан {n}?", b["city"], w, f, f"city:{k}")
        w = sample([x["name"] for x in B if x["city"] and x["city"] != b["city"]], 3)
        add("brands", t + 1, f"Какой из этих брендов основан в городе «{b['city']}»?", n, w, f, f"rcity:{k}")
    # чем известен
    w = sample([x["sig"] for x in B], 3, [b["sig"]])
    add("brands", t, f"Чем известен бренд {n}?", b["sig"], w, f, f"sig:{k}")
    w = sample(names, 3, [n])
    add("brands", t, f"Какой бренд ассоциируется с описанием: «{b['sig']}»?", n, w, f, f"rsig:{k}")
    # годы
    if b["year"]:
        y = b["year"]
        add_year("brands", t, f"В каком году основан {n}?", y, f, f"year:{k}")
        w = sample([x["name"] for x in B if x["year"] and abs(x["year"] - y) >= 8], 3)
        add("brands", t + 1, f"Какой из этих брендов основан в {y} году?", n, w, f, f"ryear:{k}")
        dec = y // 10 * 10
        w = sample([x["name"] for x in B if x["year"] and x["year"] // 10 * 10 != dec], 3)
        add("brands", t, f"Какой из этих брендов основан в {dec}-х годах?", n, w, f, f"rdec:{k}")
        younger = [x for x in B if x["year"] and x["year"] >= y + 15]
        if len(younger) >= 3:
            w = R.sample(younger, 3)
            lst = ", ".join(f"{x['name']} — {x['year']}" for x in [b] + w)
            add("brands", max(t, max(x["tier"] for x in w) - 1), "Какой из этих брендов основан раньше остальных?",
                n, [x["name"] for x in w], f"{lst}.", f"oldest:{k}")
        older = [x for x in B if x["year"] and x["year"] <= y - 15]
        if len(older) >= 3:
            w = R.sample(older, 3)
            lst = ", ".join(f"{x['name']} — {x['year']}" for x in [b] + w)
            add("brands", max(t, max(x["tier"] for x in w) - 1), "Какой из этих брендов основан позже остальных?",
                n, [x["name"] for x in w], f"{lst}.", f"newest:{k}")
    # лишний по стране
    if b["country"]:
        for _ in range(2):
            big = [c for c in LOC if c != b["country"] and sum(1 for x in B if x["country"] == c) >= 3]
            c = R.choice(big)
            w = sample([x["name"] for x in B if x["country"] == c], 3)
            if w:
                add("brands", t + 1, f"Какой из этих брендов основан НЕ {LOC[c]}?", n, w,
                    f"{f} Остальные бренды — из страны: {c}.", f"odd:{k}:{c}")

# ---------- вещи ----------
items = rows("items.txt")
for item, brand, year, tier, note in items:
    t = int(tier)
    f = f"{cap(item)} — {brand}" + (f", {year} год" if year else "") + f". {note}."
    others = [x for x in items if x[1] != brand]
    w = sample([x[1] for x in others] + [x["name"] for x in B], 3, [brand])
    add("items", t, f"Какому бренду принадлежит {item}?", brand, w, f, f"item:{item}")
    w = sample([x[0] for x in others], 3)
    add("items", t, f"Какая из этих вещей принадлежит бренду {brand}?", item, w, f, f"ritem:{item}")
    if year:
        add_year("items", t, f"В каком году появилась вещь: {item}?", int(year), f, f"iyear:{item}")

# ---------- события ----------
ev = rows("events.txt")
for e, year, tier in ev:
    t, y = int(tier), int(year)
    f = f"{cap(e)} — {y} год."
    add_year("history", t, f"В каком году {e}?", y, f, f"ev:{e}")
    w = sample([x[0] for x in ev if x[1] != year], 3)
    add("history", t + 1, f"Какое из событий произошло в {y} году?", e, w, f, f"rev:{e}")

# ---------- эпохи ----------
eras = rows("eras.txt")
decs = sorted({e[0] for e in eras})
for dec, c1, c2, c3, tier in eras:
    t = int(tier)
    w = sample(decs, 3, [dec])
    add("history", t, f"К какому десятилетию относятся приметы: {low(c1)}; {low(c2)}?", dec, w,
        f"{dec}: {low(c1)}; {low(c2)}; {low(c3)}.", f"era:{dec}:{c1[:20]}")

# ---------- термины ----------
terms = rows("terms.txt")
for term, d, tier in terms:
    t = int(tier)
    f = f"{cap(term)} — {d}."
    w = sample([x[1] for x in terms], 3, [d])
    add("terms", t, f"Что такое «{term}»?", d, w, f, f"term:{term}")
    w = sample([x[0] for x in terms], 3, [term])
    add("terms", t, f"Как называется: {d}?", term, w, f, f"rterm:{term}")

# ---------- дизайнеры ----------
roles = rows("designers_roles.txt")
role_names = sorted({r[0] for r in roles})
role_brands = sorted({r[1] for r in roles} | {x["name"] for x in B})
for name, brand, years, tier in roles:
    t = int(tier)
    f = f"{name} возглавлял(а) {brand} в {years} годах."
    held_b = {r[1] for r in roles if r[0] == name}
    w = sample(role_brands, 3, held_b)
    add("designers", t, f"Какой дом моды возглавлял(а) {name} в {years} годах?", brand, w, f, f"role:{name}:{brand}")
    held_n = {r[0] for r in roles if r[1] == brand}
    w = sample(role_names, 3, held_n)
    add("designers", t, f"Кто возглавлял {brand} в {years} годах?", name, w, f, f"rrole:{name}:{brand}")

known = rows("designers_known.txt")
for name, c1, c2, c3, tier in known:
    t = int(tier)
    f = f"{name}: {low(c1)}; {low(c2)}; {low(c3)}."
    w = sample([x[0] for x in known], 3, [name])
    add("designers", t, f"О каком дизайнере речь? {c1}. {c2}.", name, w, f, f"known:{name}")
    w = sample([x[1] for x in known], 3, [c1])
    add("designers", t + 1, f"Что верно про дизайнера {name}?", c1, w, f, f"rknown:{name}")

R.shuffle(Q)
for i, q in enumerate(Q, 1):
    q["id"] = i
(BASE / "questions.json").write_text(json.dumps(Q, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

# ---------- детектив ----------
DET = []


def dadd(kind, d, q, clues, correct, wrong, fact):
    opts = [correct] + list(wrong)
    if len(set(opts)) != 4:
        return
    R.shuffle(opts)
    DET.append({"id": len(DET) + 1, "kind": kind, "d": clamp(d), "q": q, "clues": clues,
                "options": opts, "answer": opts.index(correct), "fact": fact})


for b in B:
    parts = [p for p in (f"Страна: {b['country']}" if b["country"] else None,
                         f"основан в {b['year']} году" if b["year"] else None) if p]
    clue2 = ", ".join(parts)
    clue3 = f"Основатель: {b['founder']}" if b["founder"] else (f"Город основания: {b['city']}" if b["city"] else None)
    if not clue2 or not clue3:
        continue
    text = " ".join([b["sig"], clue2, clue3]).lower()
    if any(tok.lower() in text for tok in b["name"].replace("&", " ").split() if len(tok) > 3):
        continue
    same = [x["name"] for x in B if x["country"] == b["country"] and x["name"] != b["name"]]
    w = sample(same, 3) or sample([x["name"] for x in B], 3, [b["name"]])
    dadd("brand", b["tier"], "Какой это бренд?", [f"Приметы: {b['sig']}", clue2, clue3], b["name"], w, bfact(b))

for name, c1, c2, c3, tier in known:
    w = sample([x[0] for x in known], 3, [name])
    dadd("designer", int(tier), "Какой это дизайнер?", [c1, c2, c3], name, w, f"{name}: {low(c3)}.")

for dec, c1, c2, c3, tier in eras:
    w = sample(decs, 3, [dec])
    dadd("era", int(tier), "Какое это десятилетие?", [c1, c2, c3], dec, w, f"{dec}: {low(c1)}; {low(c2)}; {low(c3)}.")

R.shuffle(DET)
for i, c in enumerate(DET, 1):
    c["id"] = i
(BASE / "detective.json").write_text(json.dumps(DET, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

# ---------- отчёт ----------
from collections import Counter
print("вопросов:", len(Q), "| дел детектива:", len(DET))
print("по категориям:", dict(Counter(q["cat"] for q in Q)))
print("по сложности:", dict(sorted(Counter(q["d"] for q in Q).items())))
print("уникальных фактов (key без режима):", len({q["key"].rsplit(":", 1)[0] if q["key"].endswith(("wide", "narrow")) else q["key"] for q in Q}))
print("дела по видам:", dict(Counter(c["kind"] for c in DET)), dict(sorted(Counter(c["d"] for c in DET).items())))
